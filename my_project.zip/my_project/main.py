import pandas as pd
import cv2
import os
import numpy as np
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense

# 이미지 전처리 함수
def preprocess_image(img_path, target_size=(128, 128)):
    img = cv2.imread(img_path)  # 이미지 읽기
    img = cv2.resize(img, target_size)  # 크기 조정
    img = img / 255.0  # 정규화 (0~1 사이 값으로 변환)
    return img

# 학습 함수
def train_model():
    # 데이터 로드
    train_df = pd.read_csv('train.csv')

    # 학습 데이터 준비
    X_train = []
    y_train = []

    for _, row in train_df.iterrows():
        img = preprocess_image(row['img_path'])
        X_train.append(img)
        y_train.append(row['label'])

    X_train = np.array(X_train)
    y_train = np.array(y_train)

    print("학습 데이터 준비 완료!")

    # CNN 모델 정의
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(128, 128, 3)),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(1, activation='sigmoid')  # 이진 분류용
    ])

    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    model.fit(X_train, y_train, epochs=10, batch_size=32)

    # 모델 저장
    model.save('models/cnn_model.h5')
    print("모델 생성 완료!")

# 테스트 및 예측 함수
def predict_test():
    # 데이터 로드
    test_df = pd.read_csv('test.csv')

    # 테스트 데이터 준비
    X_test = []
    for _, row in test_df.iterrows():
        img = preprocess_image(row['img_path'])
        X_test.append(img)

    X_test = np.array(X_test)

    print("테스트 데이터 준비 완료!")

    # 저장된 모델 로드
    model = load_model('models/cnn_model.h5')

    # 예측
    predictions = model.predict(X_test)

    # 결과 저장
    test_df['label'] = predictions
    test_df.to_csv('submission.csv', index=False)
    print("테스트 데이터 예측 완료! 결과가 submission.csv에 저장되었습니다.")

# 메인 실행
if __name__ == '__main__':
    train_model()
    predict_test()
